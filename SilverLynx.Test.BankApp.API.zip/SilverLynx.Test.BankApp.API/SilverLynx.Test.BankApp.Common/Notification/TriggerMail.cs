﻿namespace ABB.MOTOMST.Common.Notification
{
    public class TriggerMail
    {
    }
}
