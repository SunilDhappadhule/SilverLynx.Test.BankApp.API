﻿using System.Collections.Generic;
using System.IO;

namespace ABB.MOTOMST.Common.Notification
{
    public interface ITriggerMail
    {
        bool SendNotification(List<string> recepientsList, string fromAddress, string emailSubject, string emailContent, List<string> ccAddress, MemoryStream memoryStream, string pdfName);
        bool SendGroupEmail(List<string> recepientsList, string fromAddress, string emailSubject, string emailContent, List<string> ccAddress, string FilePath, MemoryStream fileresponse = null, string fileName = "", string bccEmail = "", string CurrentOrderBUName = "");
        string HtmlEmailBody(string toName, string content);
        bool SendForgotPasswordMail(string recepientEmailId, string emailSubject, string emailContent);
    }
}
