﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABB.MOTOMST.Common.Common
{
    public static class ObjectExtensions
    {
        public static string ToStringInstance(this object obj)
        {
            if (obj == null)
            { return string.Empty; }

            return obj.ToString();
        }
        public static bool HasValue(this string str)
        {
            return string.IsNullOrWhiteSpace(str) == false;
        }

        public static Boolean Like(this string str, string other)
        {
            return str.IndexOf(other, StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}
