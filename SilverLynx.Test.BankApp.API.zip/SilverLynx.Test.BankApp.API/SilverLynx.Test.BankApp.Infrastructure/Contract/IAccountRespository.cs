﻿using SilverLynx.Test.BankApp.Persistence.Context;
using SilverLynx.Test.BankApp.Persistence.DbSetEntities;

namespace SilverLynx.Test.BankApp.Infrastructure.Contract
{
    public interface IAccountRespository:IBaseGenericRepository<Account>
    {
    }
}
