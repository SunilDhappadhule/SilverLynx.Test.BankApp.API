﻿using SilverLynx.Test.BankApp.Infrastructure.Contract;

namespace SilverLynx.Test.BankApp.Infrastructure.UnitOfWork
{
    public interface ISilverLynxBankAppUnitOfWork:IDisposable
    {
        IAccountRespository AccountRespository { get;}
        IBillPayRepository BillPayRepository { get; }
        ICustomerRespository CustomerRespository { get; }

        ILoginRespository LoginRespository { get; }

        IPayeeRespository PayeeRespository { get; }
        IStatesRespository StatesRespository { get; }
        ITransactionRespository TransactionRespository { get; }
        void CompleteTransaction();
    }
}
