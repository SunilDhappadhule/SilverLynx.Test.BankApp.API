﻿using Microsoft.Extensions.Configuration;
using SilverLynx.Test.BankApp.Infrastructure.Contract;
using SilverLynx.Test.BankApp.Infrastructure.Repository;
using SilverLynx.Test.BankApp.Persistence.Context;
using System.Configuration;

namespace SilverLynx.Test.BankApp.Infrastructure.UnitOfWork
{
    public class SilverLynxBankAppUnitOfWork : ISilverLynxBankAppUnitOfWork
    {
        private readonly SilverLynxBankAppDBContext _context;

        private readonly IConfiguration _configuration;
        public IAccountRespository AccountRespository { get; }

        public IBillPayRepository BillPayRepository { get; }

        public ICustomerRespository CustomerRespository { get; }

        public ILoginRespository LoginRespository { get; }

        public IPayeeRespository PayeeRespository { get; }

        public IStatesRespository StatesRespository { get; }

        public ITransactionRespository TransactionRespository { get; }
        public SilverLynxBankAppUnitOfWork(SilverLynxBankAppDBContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
            AccountRespository = new AccountRespository(_context);
            BillPayRepository = new BillPayRepository(_context);
            CustomerRespository = new CustomerRespository(_context);
            LoginRespository = new LoginRespository(_context);
            PayeeRespository = new PayeeRespository(_context);
            StatesRespository = new StatesRespository(_context);
        }

        public void Dispose() => this.Dispose();

        public void CompleteTransaction()
        {
            _context.SaveChanges();
        }
    }
}
