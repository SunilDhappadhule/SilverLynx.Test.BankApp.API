﻿using SilverLynx.Test.BankApp.Infrastructure.Contract;
using SilverLynx.Test.BankApp.Persistence.Context;
using SilverLynx.Test.BankApp.Persistence.DbSetEntities;

namespace SilverLynx.Test.BankApp.Infrastructure.Repository
{
    public class AccountRespository : BaseGenericRepository<Account>, IAccountRespository
    {
        public AccountRespository(SilverLynxBankAppDBContext context) : base(context)
        {
        }
    }
}
