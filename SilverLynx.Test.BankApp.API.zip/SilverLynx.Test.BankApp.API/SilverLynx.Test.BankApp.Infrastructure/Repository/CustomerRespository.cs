﻿using SilverLynx.Test.BankApp.Infrastructure.Contract;
using SilverLynx.Test.BankApp.Persistence.Context;
using SilverLynx.Test.BankApp.Persistence.DbSetEntities;

namespace SilverLynx.Test.BankApp.Infrastructure.Repository
{
    public class CustomerRespository : BaseGenericRepository<Customer>, ICustomerRespository
    {
        public CustomerRespository(SilverLynxBankAppDBContext context) : base(context)
        {
        }
    }
}
