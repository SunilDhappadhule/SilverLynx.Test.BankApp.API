﻿using SilverLynx.Test.BankApp.Infrastructure.Contract;
using SilverLynx.Test.BankApp.Persistence.Context;
using SilverLynx.Test.BankApp.Persistence.DbSetEntities;

namespace SilverLynx.Test.BankApp.Infrastructure.Repository
{
    public class StatesRespository : BaseGenericRepository<States>, IStatesRespository
    {
        public StatesRespository(SilverLynxBankAppDBContext context) : base(context)
        {
        }
    }
}
