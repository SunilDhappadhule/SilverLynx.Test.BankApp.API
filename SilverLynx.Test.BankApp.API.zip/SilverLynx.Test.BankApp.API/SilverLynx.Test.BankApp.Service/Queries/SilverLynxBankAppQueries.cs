﻿using SilverLynx.Test.BankApp.Infrastructure.UnitOfWork;
using SilverLynx.Test.BankApp.Persistence.DbSetEntities;

namespace SilverLynx.Test.BankApp.Service.Queries
{
    public class SilverLynxBankAppQueries: ISilverLynxBankAppQueries
    {
        ISilverLynxBankAppUnitOfWork silverLynxBankAppUnitOfWork;
        public SilverLynxBankAppQueries(ISilverLynxBankAppUnitOfWork _silverLynxBankAppUnitOfWork)
        {
            silverLynxBankAppUnitOfWork = _silverLynxBankAppUnitOfWork;
        }
        public async Task<Transaction> GetTransaction(int transactionID)
        {
            return await Task.Run(() =>
            {
                return silverLynxBankAppUnitOfWork.TransactionRespository.GetAll().FirstOrDefault(x => x.TransactionID == transactionID);
            });
}
       public Account GetAccountWithTransactions(int accountNumber) => silverLynxBankAppUnitOfWork.AccountRespository.GetAll().First(x => x.AccountNumber == accountNumber);

        public double GetAccountBalance(int accountNumber)
        {
           return silverLynxBankAppUnitOfWork.AccountRespository.GetAll().First(x => x.AccountNumber == accountNumber).Balance;
        }
    }
}
