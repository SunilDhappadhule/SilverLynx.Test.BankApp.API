﻿using SilverLynx.Test.BankApp.Persistence.DbSetEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SilverLynx.Test.BankApp.Service.Queries
{
    public interface ISilverLynxBankAppQueries
    {
        Task<Transaction> GetTransaction(int transactionID);
        Account GetAccountWithTransactions(int accountNumber);
        double GetAccountBalance(int accountNumber);
    }
}
