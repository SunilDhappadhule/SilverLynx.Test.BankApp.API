﻿using SilverLynx.Test.BankApp.Persistence.DbSetEntities;

namespace SilverLynx.Test.BankApp.Service.Commands
{
    public interface ISilverLynxBankAppCommands
    {
        int ProcessTransaction(Transaction transaction);
    }
}
