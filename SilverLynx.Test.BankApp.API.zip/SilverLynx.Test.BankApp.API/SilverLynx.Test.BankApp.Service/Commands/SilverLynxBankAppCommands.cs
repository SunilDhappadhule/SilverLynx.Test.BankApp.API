﻿using SilverLynx.Test.BankApp.Common.Common;
using SilverLynx.Test.BankApp.Infrastructure.UnitOfWork;
using SilverLynx.Test.BankApp.Persistence.DbSetEntities;

namespace SilverLynx.Test.BankApp.Service.Commands
{
    public class SilverLynxBankAppCommands:ISilverLynxBankAppCommands
    {
        private const int ID_LENGTH = 4;
        ISilverLynxBankAppUnitOfWork silverLynxBankAppUnitOfWork;

        public int ProcessTransaction(Transaction transaction)
        {
            // generate random transactionID until no matching ID found
            transaction.TransactionID = GenerateUniqueTransactionID();
            // add new transaction time
            transaction.ModifyDate = DateTime.UtcNow;
            Transfer(transaction);
            return transaction.TransactionID;
        }
        public SilverLynxBankAppCommands(ISilverLynxBankAppUnitOfWork _silverLynxBankAppUnitOfWork)
        {
            silverLynxBankAppUnitOfWork= _silverLynxBankAppUnitOfWork;
        }
        private int GenerateUniqueTransactionID()
        {
            int uniqueID;
            do
            {
                // repurpose utility functionality
                uniqueID = Convert.ToInt32(UtilityFunctions.GenerateStringID(ID_LENGTH));
            }
            // check generated ID doesn't exist in database already
            while (silverLynxBankAppUnitOfWork.TransactionRespository.GetByID(uniqueID) != null);

            return uniqueID;
        }
        private void Transfer(Transaction transfer)
        {
            // retrieve origin account
            var originAccount = GetAccountWithTransactions(transfer.AccountNumber);

            bool IsFree = IsTransactionFree(transfer.AccountNumber);

            double amount = transfer.Amount;

            // if transaction is not free, update balance with service charge added
            originAccount.Balance -= IsFree ? amount : amount + (amount / 5);

            originAccount.Transactions.Add(transfer);

            // add service charge if transfer is not free
            if (!IsFree)
            {
                originAccount.Transactions.Add(
                    new Transaction
                    {
                        TransactionID = GenerateUniqueTransactionID(),
                        TransactionType = (char)TransactionType.ServiceCharge,
                        AccountNumber = transfer.AccountNumber,
                        // amount is 0.2 of transfer per business rules
                        Amount = amount / 5,
                        // use transactionID of transfer in comment
                        Comment = $"Service Charge of transfer {transfer.TransactionID}",
                        ModifyDate = DateTime.UtcNow
                    });
            }

            // Update Destination Account
            // retrieve destination account
            var destinationAccount = GetAccountWithTransactions(transfer.DestAccount);

            destinationAccount.Balance += transfer.Amount;

            // add to destination account as a deposit with comment including details
            destinationAccount.Transactions.Add(
                new Transaction
                {
                    TransactionID = GenerateUniqueTransactionID(),
                    TransactionType = (char)TransactionType.Deposit,
                    AccountNumber = transfer.DestAccount,
                    Amount = transfer.Amount,
                    Comment = $"Transfer from account {transfer.AccountNumber}",
                    ModifyDate = DateTime.UtcNow
                });

            // update database
            silverLynxBankAppUnitOfWork.CompleteTransaction();
        }
        private Account GetAccountWithTransactions(int accountNumber)
        {
            return silverLynxBankAppUnitOfWork.AccountRespository.GetAll().ToList().First(x => x.AccountNumber == accountNumber);
        }

        private bool IsTransactionFree(int accountNumber)
        {
            // retrieve all transactions of an account number
            var transactions = silverLynxBankAppUnitOfWork.TransactionRespository.GetAll().Where(x => x.AccountNumber == accountNumber);

            int count = 0;
            foreach (Transaction t in transactions)
            {
                // if Withdrawal or Transfer, increment count
                if (t.TransactionType == 'W' || t.TransactionType == 'T')
                    count++;
            }

            return count < 4 ? true : false;
        }
    }
}
