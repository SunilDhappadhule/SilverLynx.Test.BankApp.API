using System;

namespace SilverLynx.Test.BankApp.Persistence.DbSetEntities
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
