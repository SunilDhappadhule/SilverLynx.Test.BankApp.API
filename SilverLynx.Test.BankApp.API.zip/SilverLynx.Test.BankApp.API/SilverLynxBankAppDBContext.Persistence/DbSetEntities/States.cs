﻿using System.Collections.Generic;

namespace SilverLynx.Test.BankApp.Persistence.DbSetEntities
{
    public class States
    {
        public string State;

        public string Value;
    }
}