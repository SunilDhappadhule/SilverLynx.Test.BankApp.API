﻿using System.Data.Entity;
using DbContext = System.Data.Entity.DbContext;

namespace SilverLynx.Test.BankApp.Persistence.Context
{
    public class EntityDatabaseTransaction : IDatabaseTransaction
    {
        private readonly DbContextTransaction _transaction;

        public EntityDatabaseTransaction(DbContext context)
        {
            _transaction = context.Database.BeginTransaction();
        }

        public void Commit()
        {
            _transaction.Commit();
        }

        public void Rollback()
        {
            _transaction.Rollback();
        }

        public void Dispose()
        {
            _transaction.Dispose();
        }
    }
}

