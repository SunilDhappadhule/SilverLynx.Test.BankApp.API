﻿namespace SilverLynx.Test.BankApp.Persistence.Context
{
    public interface IDatabaseTransaction : IDisposable
    {
        void Commit();
        void Rollback();
    }
}
