﻿using System.Linq.Expressions;

namespace SilverLynx.Test.BankApp.Persistence.Context
{
    public interface IBaseGenericRepository<T>
    {
        T GetByID(int id);

        T GetSingleEntity(Expression<Func<T, bool>> filter, string includedProperties);

        IEnumerable<T> GetAll(
            Expression<Func<T, bool>> filter = null,
            Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, string includedProperties = ""
            );

        IEnumerable<T> GetAllWithPaging(out int total,
          Expression<Func<T, bool>> filter = null,
          Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, string includedProperties = "", int page = 1, int limit = 20
          );
        // void Insert(T entity);
        T Insert(T entity);

        void InsertWithoutReturnObject(T entity);

        void InsertList(List<T> entities);

        void Update(T entity);

        void UpdateAll(List<T> entities);

        void Delete(List<T> entity);
        void DeleteSingleEntity(T entity);

        IEnumerable<T> ExecWithStoreProcedure(string query, params object[] parameters);
    }
}
