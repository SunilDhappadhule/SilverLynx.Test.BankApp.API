﻿using Microsoft.EntityFrameworkCore;
using SilverLynx.Test.BankApp.Common.Common;
using System.Linq.Expressions;

namespace SilverLynx.Test.BankApp.Persistence.Context
{
    public class BaseGenericRepository<T> : IBaseGenericRepository<T> where T : class
    {
        public SilverLynxBankAppDBContext SilverLynxBankAppDBContext;

        public DbSet<T> SilverLynxBankAppDbSet;

        public BaseGenericRepository(SilverLynxBankAppDBContext context)
        {
            this.SilverLynxBankAppDBContext = context;
            this.SilverLynxBankAppDbSet = context.Set<T>();
        }

        public T GetByID(int id)
        {
            return SilverLynxBankAppDbSet.Find(id);
        }
        public T GetSingleEntity(Expression<Func<T, bool>> filter, string includedProperties)
        {
            IQueryable<T> query = SilverLynxBankAppDbSet;
            if (filter != null)
            {
                query = query.Where(filter);
            }
            foreach (var includeProperty in includedProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                query = query.Include(includeProperty);
            }
            return query.FirstOrDefault();
        }


        public IEnumerable<T> GetAll(Expression<Func<T, bool>> filter = null, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, string includedProperties = "")
        {

            IQueryable<T> query = SilverLynxBankAppDbSet;
            var statusProperty = typeof(T).GetProperties().Where(p => p.Name == "Status").FirstOrDefault();

            var isdeletedProperty = typeof(T).GetProperties().Where(p => p.Name == "IsDeleted").FirstOrDefault();

            if (filter != null)
            {
                Expression<Func<T, bool>> result = filter;
                if (statusProperty != null && !filter.Body.ToString().Contains("Status"))
                {
                    ParameterExpression parameter = Expression.Parameter(typeof(T), "model");
                    MemberExpression memberExpression = Expression.Property(parameter, typeof(T).GetProperty("Status"));

                    result = ExpressionExtension<T>.AndAlso(filter, Expression.Lambda<Func<T, Boolean>>(memberExpression, parameter));

                }
                query = query.Where(result);

            }

            foreach (var includeProperty in includedProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                query = query.Include(includeProperty);
            }

            if (orderBy != null)
            {
                return orderBy(query).ToList();
            }
            else
            {
                return query.ToList();
            }

        }

        public T Insert(T entity)
        {

            SilverLynxBankAppDbSet.Add(entity);
            this.SilverLynxBankAppDBContext.SaveChanges();
            return entity;
        }
        public void InsertWithoutReturnObject(T entity)
        {
            SilverLynxBankAppDbSet.Add(entity);
            this.SilverLynxBankAppDBContext.SaveChanges();
        }

        public void InsertList(List<T> entities)
        {
            foreach (T entity in entities)
            {
                SilverLynxBankAppDbSet.Add(entity);
            }
            this.SilverLynxBankAppDBContext.SaveChanges();
        }


        //public void Insert(T entity)
        //{
        //    MotorMasterDbSet.Add(entity);
        //    this.MotorMaster.SaveChanges();
        //}

        public void Update(T entity)
        {
            SilverLynxBankAppDbSet.Attach(entity);
            SilverLynxBankAppDBContext.Entry(entity).State = EntityState.Modified;

            //var datetimeProperty = typeof(T).GetProperties().Where(p => p.Name == "CreatedDateTime").FirstOrDefault();
            //if (datetimeProperty != null)
            //{
            //    MotorMaster.Entry(entity).Property("CreatedDateTime").IsModified = false;
            //}
            //var createdByProperty = typeof(T).GetProperties().Where(p => p.Name == "CreatedBy").FirstOrDefault();
            //if (createdByProperty != null)
            //{
            //    MotorMaster.Entry(entity).Property("CreatedBy").IsModified = false;
            //}
            ////***********Sample to update a generic value to a field***************
            ////MotorMaster.Entry(entity).Property("Description").CurrentValue = "Testing";
            //var updatedTimeProperty = typeof(T).GetProperties().Where(p => p.Name == "LastUpdatedDateTime").FirstOrDefault();
            //if (updatedTimeProperty != null)
            //{
            //    MotorMaster.Entry(entity).Property("LastUpdatedDateTime").CurrentValue = DateTime.Now;
            //}

            this.SilverLynxBankAppDBContext.SaveChanges();
        }

        public void UpdateAll(List<T> entities)
        {
            bool createdDateTimeFieldExists = false;
            var datetimeProperty = typeof(T).GetProperties().Where(p => p.Name == "CreatedDateTime").FirstOrDefault();
            if (datetimeProperty != null)
            {
                createdDateTimeFieldExists = true;
            }
            bool createdByFieldExists = false;
            var createdByProperty = typeof(T).GetProperties().Where(p => p.Name == "CreatedBy").FirstOrDefault();
            if (datetimeProperty != null)
            {
                createdByFieldExists = true;
            }


            bool lastupdateByFieldExists = false;
            var lastupdatedByProperty = typeof(T).GetProperties().Where(p => p.Name == "LastUpdatedDateTime").FirstOrDefault();
            if (lastupdatedByProperty != null)
            {
                lastupdateByFieldExists = true;
            }

            foreach (T entity in entities)
            {
                SilverLynxBankAppDbSet.Attach(entity);
                this.SilverLynxBankAppDBContext.Entry(entity).State = EntityState.Modified;
                if (createdDateTimeFieldExists)
                {
                    SilverLynxBankAppDBContext.Entry(entity).Property("CreatedDateTime").IsModified = false;
                }
                if (createdByFieldExists)
                {
                    SilverLynxBankAppDBContext.Entry(entity).Property("CreatedBy").IsModified = false;
                }
                if (lastupdateByFieldExists)
                {
                    SilverLynxBankAppDBContext.Entry(entity).Property("LastUpdatedDateTime").CurrentValue = DateTime.Now;
                }
            }
            this.SilverLynxBankAppDBContext.SaveChanges();
        }

        public void Delete(List<T> entities)
        {
            foreach (T entity in entities)
            {
                this.SilverLynxBankAppDBContext.Entry(entity).State = EntityState.Deleted;
            }
            this.SilverLynxBankAppDBContext.SaveChanges();
            // throw new NotImplementedException();
        }
        public void DeleteSingleEntity(T entity)
        {
            this.SilverLynxBankAppDBContext.Entry(entity).State = EntityState.Deleted;
            this.SilverLynxBankAppDBContext.SaveChanges();
        }

        public IEnumerable<T> ExecWithStoreProcedure(string query, params object[] parameters)
        {
            return SilverLynxBankAppDBContext.Database.SqlQueryRaw<T>(query, parameters).ToList();
        }

        public IEnumerable<T> GetAllWithPaging(out int total, Expression<Func<T, bool>> filter = null, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, string includedProperties = "", int page = 1, int limit = 20)
        {

            IQueryable<T> query = SilverLynxBankAppDbSet;
            var statusProperty = typeof(T).GetProperties().Where(p => p.Name == "Status").FirstOrDefault();

            var isdeletedProperty = typeof(T).GetProperties().Where(p => p.Name == "IsDeleted").FirstOrDefault();

            if (filter != null)
            {
                Expression<Func<T, Boolean>> result = filter;
                if (statusProperty != null && !filter.Body.ToString().Contains("Status"))
                {
                    ParameterExpression parameter = Expression.Parameter(typeof(T), "model");
                    MemberExpression memberExpression = Expression.Property(parameter, typeof(T).GetProperty("Status"));
                    //LambdaExpression lambda = Expression.Lambda(memberExpression, parameter);
                    //Expression<Func<T, Boolean>> result = ExpressionExtension<T>.AndAlso(filter, lambda);

                    result = ExpressionExtension<T>.AndAlso(filter, Expression.Lambda<Func<T, Boolean>>(memberExpression, parameter));


                }
                //if (isdeletedProperty != null && !filter.Body.ToString().Contains("IsDeleted"))
                //{
                //    ParameterExpression parameter = Expression.Parameter(typeof(T), "model");
                //    MemberExpression memberExpression = Expression.Property(parameter, typeof(T).GetProperty("IsDeleted"));
                //    //LambdaExpression lambda = Expression.Lambda(memberExpression, parameter);
                //    //Expression<Func<T, Boolean>> result = ExpressionExtension<T>.AndAlso(filter, lambda);

                //    result = ExpressionExtension<T>.AndAlso(result, Expression.Lambda<Func<T, Boolean>>(memberExpression, parameter));


                //}
                query = query.Where(result);

            }


            foreach (var includeProperty in includedProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
            {
                query = query.Include(includeProperty);
            }

            if (orderBy != null)
            {
                total = query.Count();
                return orderBy(query).Skip((page - 1) * limit).Take(limit).ToList();
            }
            else
            {
                total = query.Count();
                return query.ToList();
            }


        }




    }
}
