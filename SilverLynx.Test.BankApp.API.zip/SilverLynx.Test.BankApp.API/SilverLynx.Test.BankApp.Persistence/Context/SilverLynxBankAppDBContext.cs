﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SilverLynx.Test.BankApp.Persistence.Context
{
    internal class SilverLynxBankAppDBContext
    {
    }
}
