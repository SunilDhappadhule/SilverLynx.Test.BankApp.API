USE [master]
GO
/****** Object:  Database [SilverSampleBankdb]    Script Date: 3/20/2023 12:52:59 AM ******/
CREATE DATABASE [SilverSampleBankdb]

ALTER DATABASE [SilverSampleBankdb] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [SilverSampleBankdb].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [SilverSampleBankdb] SET ANSI_NULL_DEFAULT ON 
GO
ALTER DATABASE [SilverSampleBankdb] SET ANSI_NULLS ON 
GO
ALTER DATABASE [SilverSampleBankdb] SET ANSI_PADDING ON 
GO
ALTER DATABASE [SilverSampleBankdb] SET ANSI_WARNINGS ON 
GO
ALTER DATABASE [SilverSampleBankdb] SET ARITHABORT ON 
GO
ALTER DATABASE [SilverSampleBankdb] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [SilverSampleBankdb] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET CURSOR_DEFAULT  LOCAL 
GO
ALTER DATABASE [SilverSampleBankdb] SET CONCAT_NULL_YIELDS_NULL ON 
GO
ALTER DATABASE [SilverSampleBankdb] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET QUOTED_IDENTIFIER ON 
GO
ALTER DATABASE [SilverSampleBankdb] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET  DISABLE_BROKER 
GO
ALTER DATABASE [SilverSampleBankdb] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [SilverSampleBankdb] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET RECOVERY FULL 
GO
ALTER DATABASE [SilverSampleBankdb] SET  MULTI_USER 
GO
ALTER DATABASE [SilverSampleBankdb] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [SilverSampleBankdb] SET DB_CHAINING OFF 
GO
ALTER DATABASE [SilverSampleBankdb] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [SilverSampleBankdb] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [SilverSampleBankdb] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [SilverSampleBankdb] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [SilverSampleBankdb] SET QUERY_STORE = OFF
GO
USE [SilverSampleBankdb]
GO
/****** Object:  Table [dbo].[__EFMigrationsHistory]    Script Date: 3/20/2023 12:52:59 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[__EFMigrationsHistory](
	[MigrationId] [nvarchar](150) NOT NULL,
	[ProductVersion] [nvarchar](32) NOT NULL,
 CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY CLUSTERED 
(
	[MigrationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Accounts]    Script Date: 3/20/2023 12:52:59 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Accounts](
	[AccountNumber] [int] NOT NULL,
	[AccountType] [nvarchar](1) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[Balance] [float] NOT NULL,
	[ModifyDate] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_Accounts] PRIMARY KEY CLUSTERED 
(
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[BillPays]    Script Date: 3/20/2023 12:52:59 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BillPays](
	[BillPayID] [int] NOT NULL,
	[AccountNumber] [int] NOT NULL,
	[PayeeID] [int] NOT NULL,
	[Amount] [float] NOT NULL,
	[ScheduleDate] [datetime2](7) NOT NULL,
	[Period] [nvarchar](1) NOT NULL,
	[ModifyDate] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_BillPays] PRIMARY KEY CLUSTERED 
(
	[BillPayID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Customers]    Script Date: 3/20/2023 12:52:59 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Customers](
	[CustomerID] [int] NOT NULL,
	[CustomerName] [nvarchar](50) NOT NULL,
	[TFN] [nvarchar](9) NULL,
	[Address] [nvarchar](50) NULL,
	[City] [nvarchar](40) NULL,
	[State] [nvarchar](3) NULL,
	[PostCode] [nvarchar](max) NULL,
	[Phone] [nvarchar](max) NULL,
 CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED 
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Logins]    Script Date: 3/20/2023 12:52:59 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Logins](
	[UserID] [nvarchar](8) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[Password] [nvarchar](max) NOT NULL,
	[ModifyDate] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_Logins] PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Payees]    Script Date: 3/20/2023 12:52:59 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Payees](
	[PayeeID] [int] NOT NULL,
	[PayeeName] [nvarchar](50) NOT NULL,
	[Address] [nvarchar](50) NULL,
	[City] [nvarchar](40) NULL,
	[State] [nvarchar](20) NULL,
	[PostCode] [nvarchar](max) NULL,
	[Phone] [nvarchar](15) NOT NULL,
 CONSTRAINT [PK_Payees] PRIMARY KEY CLUSTERED 
(
	[PayeeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Transactions]    Script Date: 3/20/2023 12:52:59 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Transactions](
	[TransactionID] [int] NOT NULL,
	[TransactionType] [nvarchar](1) NOT NULL,
	[AccountNumber] [int] NOT NULL,
	[DestAccount] [int] NOT NULL,
	[Amount] [float] NOT NULL,
	[Comment] [nvarchar](255) NULL,
	[ModifyDate] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_Transactions] PRIMARY KEY CLUSTERED 
(
	[TransactionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Index [IX_Accounts_CustomerID]    Script Date: 3/20/2023 12:52:59 AM ******/
CREATE NONCLUSTERED INDEX [IX_Accounts_CustomerID] ON [dbo].[Accounts]
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_BillPays_AccountNumber]    Script Date: 3/20/2023 12:52:59 AM ******/
CREATE NONCLUSTERED INDEX [IX_BillPays_AccountNumber] ON [dbo].[BillPays]
(
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_BillPays_PayeeID]    Script Date: 3/20/2023 12:52:59 AM ******/
CREATE NONCLUSTERED INDEX [IX_BillPays_PayeeID] ON [dbo].[BillPays]
(
	[PayeeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Logins_CustomerID]    Script Date: 3/20/2023 12:52:59 AM ******/
CREATE NONCLUSTERED INDEX [IX_Logins_CustomerID] ON [dbo].[Logins]
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Transactions_AccountNumber]    Script Date: 3/20/2023 12:52:59 AM ******/
CREATE NONCLUSTERED INDEX [IX_Transactions_AccountNumber] ON [dbo].[Transactions]
(
	[AccountNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Accounts]  WITH CHECK ADD  CONSTRAINT [FK_Accounts_Customers_CustomerID] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customers] ([CustomerID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Accounts] CHECK CONSTRAINT [FK_Accounts_Customers_CustomerID]
GO
ALTER TABLE [dbo].[BillPays]  WITH CHECK ADD  CONSTRAINT [FK_BillPays_Accounts_AccountNumber] FOREIGN KEY([AccountNumber])
REFERENCES [dbo].[Accounts] ([AccountNumber])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BillPays] CHECK CONSTRAINT [FK_BillPays_Accounts_AccountNumber]
GO
ALTER TABLE [dbo].[BillPays]  WITH CHECK ADD  CONSTRAINT [FK_BillPays_Payees_PayeeID] FOREIGN KEY([PayeeID])
REFERENCES [dbo].[Payees] ([PayeeID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BillPays] CHECK CONSTRAINT [FK_BillPays_Payees_PayeeID]
GO
ALTER TABLE [dbo].[Logins]  WITH CHECK ADD  CONSTRAINT [FK_Logins_Customers_CustomerID] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customers] ([CustomerID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Logins] CHECK CONSTRAINT [FK_Logins_Customers_CustomerID]
GO
ALTER TABLE [dbo].[Transactions]  WITH CHECK ADD  CONSTRAINT [FK_Transactions_Accounts_AccountNumber] FOREIGN KEY([AccountNumber])
REFERENCES [dbo].[Accounts] ([AccountNumber])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Transactions] CHECK CONSTRAINT [FK_Transactions_Accounts_AccountNumber]
GO
ALTER TABLE [dbo].[Accounts]  WITH CHECK ADD  CONSTRAINT [CH_Account_AccountNumber] CHECK  ((len([AccountNumber])=(4)))
GO
ALTER TABLE [dbo].[Accounts] CHECK CONSTRAINT [CH_Account_AccountNumber]
GO
ALTER TABLE [dbo].[Accounts]  WITH CHECK ADD  CONSTRAINT [CH_Account_AccountType] CHECK  (([AccountType]='S' OR [AccountType]='C'))
GO
ALTER TABLE [dbo].[Accounts] CHECK CONSTRAINT [CH_Account_AccountType]
GO
ALTER TABLE [dbo].[BillPays]  WITH CHECK ADD  CONSTRAINT [CH_BillPay_Amount] CHECK  (([Amount]>(0)))
GO
ALTER TABLE [dbo].[BillPays] CHECK CONSTRAINT [CH_BillPay_Amount]
GO
ALTER TABLE [dbo].[BillPays]  WITH CHECK ADD  CONSTRAINT [CH_BillPay_BillPayID] CHECK  ((len([BillPayID])=(4)))
GO
ALTER TABLE [dbo].[BillPays] CHECK CONSTRAINT [CH_BillPay_BillPayID]
GO
ALTER TABLE [dbo].[BillPays]  WITH CHECK ADD  CONSTRAINT [CH_BillPay_Period] CHECK  (([Period]='S' OR [Period]='A' OR [Period]='Q' OR [Period]='M'))
GO
ALTER TABLE [dbo].[BillPays] CHECK CONSTRAINT [CH_BillPay_Period]
GO
ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [CH_Customer_CustomerID] CHECK  ((len([CustomerID])=(4)))
GO
ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [CH_Customer_CustomerID]
GO
ALTER TABLE [dbo].[Customers]  WITH CHECK ADD  CONSTRAINT [CH_Customer_PostCode] CHECK  ((len([PostCode])=(4)))
GO
ALTER TABLE [dbo].[Customers] CHECK CONSTRAINT [CH_Customer_PostCode]
GO
ALTER TABLE [dbo].[Logins]  WITH CHECK ADD  CONSTRAINT [CH_Login_CustomerID] CHECK  ((len([CustomerID])=(4)))
GO
ALTER TABLE [dbo].[Logins] CHECK CONSTRAINT [CH_Login_CustomerID]
GO
ALTER TABLE [dbo].[Logins]  WITH CHECK ADD  CONSTRAINT [CH_Login_Password] CHECK  ((len([Password])=(64)))
GO
ALTER TABLE [dbo].[Logins] CHECK CONSTRAINT [CH_Login_Password]
GO
ALTER TABLE [dbo].[Payees]  WITH CHECK ADD  CONSTRAINT [CH_Payee_PayeeID] CHECK  ((len([PayeeID])=(4)))
GO
ALTER TABLE [dbo].[Payees] CHECK CONSTRAINT [CH_Payee_PayeeID]
GO
ALTER TABLE [dbo].[Transactions]  WITH CHECK ADD  CONSTRAINT [CH_Transaction_Amount] CHECK  (([Amount]>(0)))
GO
ALTER TABLE [dbo].[Transactions] CHECK CONSTRAINT [CH_Transaction_Amount]
GO
ALTER TABLE [dbo].[Transactions]  WITH CHECK ADD  CONSTRAINT [CH_Transaction_TransactionID] CHECK  ((len([TransactionID])=(4)))
GO
ALTER TABLE [dbo].[Transactions] CHECK CONSTRAINT [CH_Transaction_TransactionID]
GO
ALTER TABLE [dbo].[Transactions]  WITH CHECK ADD  CONSTRAINT [CH_Transaction_TransactionType] CHECK  (([TransactionType]='B' OR [TransactionType]='S' OR [TransactionType]='T' OR [TransactionType]='W' OR [TransactionType]='D'))
GO
ALTER TABLE [dbo].[Transactions] CHECK CONSTRAINT [CH_Transaction_TransactionType]
GO
USE [master]
GO
ALTER DATABASE [SilverSampleBankdb] SET  READ_WRITE 
GO
