using SilverLynx.Test.BankApp.API;

namespace ECL.Service
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }
        /// <summary>
        /// CreateHostBuilder
        /// </summary>
        /// <param name="args"></param>
        /// <returns>CreateHostBuilder</returns>
        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
.ConfigureLogging(logBuilder =>
{
    logBuilder.ClearProviders(); // removes all providers from LoggerFactory
    logBuilder.AddConsole();
    logBuilder.AddTraceSource("Information, ActivityTracing"); // Add Trace listener provider
}).
ConfigureWebHostDefaults(webBuilder =>
{
    webBuilder.UseStartup<Startup>();
});
        }
    }
}
