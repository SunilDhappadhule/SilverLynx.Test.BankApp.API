﻿using Microsoft.AspNetCore.Mvc;
using SilverLynx.Test.BankApp.Persistence.DbSetEntities;
using SilverLynx.Test.BankApp.Service.Commands;
using SilverLynx.Test.BankApp.Service.Queries;

namespace SilverLynx.Test.BankApp.API.Controllers
{
    public class BankingController : Controller
    {
       private readonly ISilverLynxBankAppCommands silverLynxBankAppCommands;
        private readonly  ISilverLynxBankAppQueries silverLynxBankAppQueries;
        public BankingController(ISilverLynxBankAppCommands _silverLynxBankAppCommands, ISilverLynxBankAppQueries _silverLynxBankAppQueries)
        {
            silverLynxBankAppCommands= _silverLynxBankAppCommands;
            silverLynxBankAppQueries= _silverLynxBankAppQueries;
        }
        [HttpPost]
        [Route("api/ProcessTransaction")]
        public IActionResult ProcessTransaction(Transaction transaction)
        {
            if (transaction != null)
            {
                return Ok(silverLynxBankAppCommands.ProcessTransaction(transaction));
            }
            return NotFound();
        }
        [HttpGet]
        [Route("api/GetAccountWithTransactions")]
        public IActionResult GetAccountWithTransactions(int accountNumber)
        {
            if (accountNumber>0)
            {
                return Ok(silverLynxBankAppQueries.GetAccountWithTransactions(accountNumber));
            }
            return NotFound();
        }
        [HttpGet]
        [Route("api/GetTransaction")]
        public IActionResult ProcessTransaction(int transaction)
        {
            if (transaction>0)
            {
                return Ok(silverLynxBankAppQueries.GetTransaction(transaction));
            }
            return NotFound();
        }
        [HttpGet]
        [Route("api/GetAccountBalance")]
        public IActionResult GetAccountBalance(int accountNumber)
        {
            if (accountNumber > 0)
            {
                return Ok(silverLynxBankAppQueries.GetAccountBalance(accountNumber));
            }
            return NotFound();
        }
    }
}
