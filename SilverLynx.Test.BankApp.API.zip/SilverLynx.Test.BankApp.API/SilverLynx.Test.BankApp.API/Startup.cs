﻿using Microsoft.EntityFrameworkCore;
using SilverLynx.Test.BankApp.Infrastructure.UnitOfWork;
using SilverLynx.Test.BankApp.Persistence.Context;
using SilverLynx.Test.BankApp.Service.Commands;
using SilverLynx.Test.BankApp.Service.Queries;
using System.Globalization;

namespace SilverLynx.Test.BankApp.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v2", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "SilverLynxBankApp-APIs",
                    Version = "v2",
                    Description = "SilverLynxBankApp-APIs  ",
                });
            });
            // Currency settings from Matthew to display all currency in AUD
            var cultureInfo = new CultureInfo("en-AU");
            cultureInfo.NumberFormat.CurrencySymbol = "$";
            CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
            CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;

            services.AddControllersWithViews();
            services.AddDbContext<SilverLynxBankAppDBContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString(nameof(SilverLynxBankAppDBContext)));
            });

            services.AddSession(options =>
            {
                // Make the session cookie essential.
                options.Cookie.IsEssential = true;
            });

            services.AddScoped(typeof(IBaseGenericRepository<>), typeof(BaseGenericRepository<>));
            services.AddScoped<ISilverLynxBankAppUnitOfWork, SilverLynxBankAppUnitOfWork>();
            services.AddTransient<ISilverLynxBankAppCommands, SilverLynxBankAppCommands>();
            services.AddScoped<ISilverLynxBankAppQueries, SilverLynxBankAppQueries>();
            //Adding a service that allows scheduled checks on the database

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseSwagger();

            //// Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            //// specifying the Swagger JSON endpoint.

            app.UseSwaggerUI(options => options.SwaggerEndpoint("/swagger/v2/swagger.json", "SilverLynxBankApp-APIs"));

            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseEndpoints(endpoints => endpoints.MapControllers());

        }
    }
}
